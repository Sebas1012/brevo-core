# brevo-core
Librería para la conexión entre NodeMCU y Brevo.
